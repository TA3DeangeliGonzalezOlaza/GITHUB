<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Persona.class.php');
require_once('../clases/Comenta.class.php');
require_once('../clases/Transaccion.class.php');	
require_once('../clases/Usuario.class.php');	
require_once('../clases/Permuta.class.php');     
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
		<div class="container">
			<nav class="navbar navbar-inverse navbar-fixed-top">
				  <div class="container">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					  </button>
					  <a class="navbar-brand" href="#">BACKEND </a>
					  


					</div>
					
					<div id="navbar" class="navbar-collapse collapse">
					
					  <form class="navbar-form navbar-right">
					  
						<!--<div class="form-group">
						  <input type="text" placeholder="Buscar..." class="form-control">
						</div>
						<button type="submit" class="btn btn-danger" >BUSCAR</button>-->
						<!--<button type="submit" class="btn btn-warning btn-sm" >Ingresar</button>-->

		
								<div class="dropdown">


										<a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a>
										<a href="Login.php" class="btn btn-warning btn-sm">Registrarse</a>
								</div>	
					
		
					  </form>
					  
					</div><!--/.navbar-collapse -->
				  </div>
			</nav>
		</div>
		
		</div>
		<div class="jumbotron">
			<div class="container">
				<div class="row">
				
				
						<div class="col-md-12">		  
							<a href="BackUsuario.php" class="btn btn-warning btn-sm">Usuarios</a>
							<a href="BackPersona.php" class="btn btn-warning btn-sm">Personas</a>
							<a href="BackPublicacion.php" class="btn btn-warning btn-sm">Publicaciones</a>
							<a href="BackTransaccion.php" class="btn btn-warning btn-sm">Transacciones</a>
							<a href="BackComenta.php" class="btn btn-warning btn-sm">Comentarios</a>
							<a href="BackPermuta.php" class="btn btn-warning btn-sm">Permutas</a>
							<div class="panel panel-default">
								<div class="panel-body re-scrollable">
										<table class="table">
													BUSCAR
													<form class="forma-busqueda cf" action="/search.php" method="post">
														<label for="search_box">
														<span> </span>
														</label>
														<input name="keywords" id="search_box" type="text" placeholder="presiona enter" >
														<input type="hidden" name="action" value="do_search" class="boton44"/>
													</form>	<br>
													<tr>
														<th>Id Usuario</th>
														<th>Reputacion</th>
														<th>Suspendido</th>
														<th>Rol</th>
														<th>Cuanta Premium</th>
														<th>Id Persona</th>
														<th></th>
														<th></th>

													</tr>										
												<?php
													$conex = conectar();
													$d = new Usuario();
													$datos_d=$d->consultaTodos($conex);
													$cuenta=count($datos_d);
												?>
													
												<?php
												for ($i=0;$i<$cuenta;$i++)
												{
												?>
													<tr class="p" >
													
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][0]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][1]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][2]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][3]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][4]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][5]?></a></td>
															<td><a href="singin.php" class="btn btn-warning btn-sm">Premium</a></td>
															<td><a href="../Logica/procesasancion.php?idusu=<?php echo $datos_d[$i][0]?>"class="btn btn-Danger btn-sm">Sancionar</a></td>
															<td><a href="../Logica/procesalevantasancion.php?idusu=<?php echo $datos_d[$i][0]?>"class="btn btn-Success btn-sm">Levantar Sancion</a></td>
														

													</tr>
															
													
												<?php
												}
												?>	
										</table>
								
								
								
								</div>
							</div>
						
						</div>
						
							<div class="col-md-6">
							
								<button data-toggle="collapse" data-target="#Estadisticas" class="btn btn-sm btn-block" style="background-color:F5BC6B" ><h4 style="color:FFFFFF">Estadisticas</h4></button>	

								<div id="Estadisticas" class="collapse">
								
								
										
										<div><a href="Estadistica-MaxVenta.php"><b><h5>Mayores vendedores</h5></b></a></div>
										<div><a href="Estadistica-Premium.php"><b><h5>Vendedores premium</h5></b></a></div>
										
										<div><a href="Estadistica-Pubmasvendidas.php"><b><h5>Publicacion mas vendida</h5></b></a></div>
										<div><a href="#"><b><h5>Publicacion mas comentada</h5></b></a></div>
										
										<div><a href="#"><b><h5>Total de ventas al mes</h5></b></a></div>
										<div><a href="#"><b><h5>Total de ventas al año</h5></b></a></div>
								
								
								
								
								
								
								
								
								
								
								</div>
													
													
							</div>	

				</div>	
		
			</div>
		</div>







 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>

<?php

?>