<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Usuario.class.php');
require_once('../clases/Comenta.class.php');	
require_once('../clases/Transaccion.class.php');	

$id_pub= strip_tags(trim($_GET['id_pub']));   

$foto= strip_tags(trim($_GET['foto'])); 

$puntajetotal = "0"   

?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">	
	
	</head>
<body>
		<div class="container">
			<nav class="navbar navbar-inverse navbar-fixed-top">
				<div class="container">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					  </button>
					  <a class="navbar-brand" href="index.php?categoria=Index&pagina=0">VendoYA.com</a>
					  <div class="navbar-brand">
							<form class="forma-busqueda cf" action="busqueda.php" method="post">
								<label for="search_box">
								<span> </span>
								</label>
								<input name="keywords" id="search_box" type="text" placeholder="" >
								<input type="hidden" name="action" value="do_search" class="boton44"/>
							</form>
					  
					  </div>
					</div>
						<div id="navbar" class="navbar-collapse collapse">
						
							<form class="navbar-form navbar-right">
							  
								<!--<div class="form-group">
								  <input type="text" placeholder="Buscar..." class="form-control">
								</div>
								<button type="submit" class="btn btn-danger" >BUSCAR</button>-->
								<!--<button type="submit" class="btn btn-warning btn-sm" >Ingresar</button>-->
								<a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a>
								<a href="Login.php" class="btn btn-warning btn-sm">Registrarse</a>
				
						
				
			
							</form>
						</div>
				</div>
		</div>					<?php
										$fechaactual = date("Y-m-d");
										$conex = conectar();
										$d = new Publicacion($id_pub);
										$datos_d=$d->consultaUno($conex);
										$cuenta=count($datos_d);
									?>
									<?php
									for ($i=0;$i<$cuenta;$i++)
									{
									?>
									<?php $id_pub = $datos_d[$i][0]?>
									<?php $id_usup = $datos_d[$i][1]?>
									<?php $nom_pub = $datos_d[$i][2]?>
									<?php $precio = $datos_d[$i][3]?>
									<?php $stock = $datos_d[$i][4]?>
									<?php $descripcion = $datos_d[$i][5]?>
									<?php $imgportada = $datos_d[$i][6]?>
									<?php $img02 = $datos_d[$i][7]?>
									<?php $img03 = $datos_d[$i][8]?>
									<?php $estado = $datos_d[$i][9]?>
									<?php $fecha = $datos_d[$i][10]?>
									<?php $permuta = $datos_d[$i][11]?>
									<?php $categoria = $datos_d[$i][12]?>
									<?php $denunciado = $datos_d[$i][13]?>
									<?php $activo = $datos_d[$i][14]?>
									
									
									
									<?php
											
											$conex = conectar();
											$u = new Usuario($id_usup);
											$datos_u=$u->consultaUno($conex);
											$cuentau=count($datos_u);
										?>
										
											<?php
											for ($i=0;$i<$cuentau;$i++)
											{
											?>
									<?php $id_usu = $datos_u[$i][0]?>
									<?php $reputacion = $datos_u[$i][1]?>
									<?php $suspendido = $datos_u[$i][2]?>
									<?php $rol = $datos_u[$i][3]?>
									<?php $premium = $datos_u[$i][4]?>
									<?php $id_per = $datos_u[$i][5]?>									

									<?php
												$id_comenpub = $datos_d[$i][0];	
												$conex = conectar();
												$c = new Comenta('','',$id_comenpub);
												$datos_c=$c->consultaTodosPub($conex);
												$cuentac=count($datos_c);
											?>
											<table>
												<?php
												for ($i=0;$i<$cuentac;$i++)
												{
												?>
												
										<?php $id_com = $datos_c[$i][0]?>
										<?php $id_usucomenta = $datos_c[$i][1]?>
										<?php $id_pub_comentada = $datos_c[$i][2]?>
										<?php $comentario = $datos_c[$i][3]?>
										<?php $com_denunciado = $datos_c[$i][4]?>
										<?php $respuesta = $datos_c[$i][5]?>
										<?php $respondido = $datos_c[$i][6]?>
										

										
								<?php
								}
								?>
								
								
								
									<?php
												
												$conex = conectar();
												$v = new Transaccion('','',$id_pub);
												$datos_v=$v->vecesVendida($conex);
												$cuentav=count($datos_v);
											?>
											
												<?php
												for ($i=0;$i<$cuentav;$i++)
												{
												?>
												
										<?php $veces = $datos_v[$i][0]?>
										
										

										
								<?php
								}
								?>
								
								
								
								
								
																<?php
													
														$conex = conectar();
														$r = new Publicacion('',$id_usup);
														$datos_r=$r->consultaVentas($conex);
														$cuentar=count($datos_r);

													?>
													
												<?php
												for ($i=0;$i<$cuentar;$i++)
												{
												?>
												
												
															<?php $id_trans = $datos_r[$i][0]?>
															<?php $id_usut = $datos_r[$i][1]?>
															<?php $id_pubt = $datos_r[$i][2]?>
															<?php $precio_finalt = $datos_r[$i][3]?>
															<?php $fechat = $datos_r[$i][4]?>
															<?php $cantidad = $datos_r[$i][5]?>
															<?php $calificaciont = $datos_r[$i][6]?>
															<?php $pago_comision = $datos_r[$i][7]?>
															<?php $comision_monto = $datos_r[$i][8]?>
															<?php $nom_pubv = $datos_r[$i][13]?>
												
												
															
															<?php $puntajetotal = $puntajetotal + $calificaciont;?>

													
												<?php
												}
												?>	
									
									


	<div class="jumbotron">
		<div class="container">
		<div class="col-md-12">
			<div class="container text-center">
			
			
			
			<div class="col-md-3 container-fluid">
			<a href="menucategoria.php?categoria=<?php echo $categoria ?>" ><?php echo $categoria ?>
			</a>><a href="articulo.php?id_pub=<?php echo $id_pub?>" value="" ><?php echo $nom_pub?></a>
			<br>
			</div>
			
			
			
			<div class="col-md-6">
			<h1 class="text-danger"><?php echo $nom_pub ?></h1>
			</div>
			<div class="col-md-3 offset-9">
			<h6>PUBLICACION # <?php echo $id_pub ;?></h6>
			</div>

			
			</div>
		</div>
		
		
					<?php
			if ($activo=="no"){?>
			<H2>FINALIZADA</H2>

			<?php
			}
			
			?>
			
			<div class="col-md-12 text-center">
			<h6 class="fa fa-shopping-cart">&nbsp <?php echo $veces ;?>&nbsp ARTICULOS VENDIDOS</h6>
			
			</div>
			

				<div class="container">
				<div class="col-md-12">
			<div class="panel panel-default">
			<div class="panel-body">
					<form action="../Logica/procesacompra.php" method="POST">
						<div class="row col-md-6">
						<div class="row col-md-12">
						<?php if ($foto==0){
						?>
							<img src="../ImagenesPubli/<?php echo $id_usup; ?>/<?php echo $nom_pub; ?>/<?php echo $imgportada; ?>" alt="imagen" width="200" height="200">
						<?php
						}
						?>
						
						<?php if ($foto==1){
						?>
							<img src="../ImagenesPubli/<?php echo $id_usup; ?>/<?php echo $nom_pub; ?>/<?php echo $img02; ?>" alt="imagen" width="200" height="200">
												
							
						<?php
						}
						?>
						
						<?php if ($foto==2){
						?>
							<img src="../ImagenesPubli/<?php echo $id_usup; ?>/<?php echo $nom_pub; ?>/<?php echo $img03; ?>" alt="imagen" width="200" height="200">
						<?php
						}
						?>
						</div>
						<div class="row col-md-12">
							<ul class="pagination">
							  <li><a href="articulo.php?id_pub=<?php echo $id_pub?>&foto=0">1</a></li>
							  <li><a href="articulo.php?id_pub=<?php echo $id_pub?>&foto=1">2</a></li>
							  <li><a href="articulo.php?id_pub=<?php echo $id_pub?>&foto=2">3</a></li>
							</ul>
						</div>
						</div>
						<div class="row col-md-4">
							<div class="col-md-12">
								<h2>$<?php echo $precio ?></h2>
							</div>
							<div class="col-md-12">
								<strong> Estado: <?php echo $estado ?> </strong><br>
							</div>
							<div class="col-md-12">
							<strong>Cantidad</strong><br>
							<input type="number" min="1" max="<?php echo $stock ?>" class="" name="cantidad" value="1" >
							</div>
							
							<div class="col-md-12">
							
							<h4>Calificacion de Vendedor</h4> 

									<?php
									if ($puntajetotal <= "-5"){
									?>
									
				
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default" style="background-color: #DF3928">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>
									

									
								<?php
								if ($puntajetotal == "-4"){
								?>
									
			
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default" style="background-color: #DF7E28">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>
									
								<?php
								if ($puntajetotal == "-3"){
								?>
									
				
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default" style="background-color: #DFB828">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>

								<?php
								if ($puntajetotal == "-2"){
								?>
									
					
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default" style="background-color: #D4DF28">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>
						
								<?php
								if ($puntajetotal == "-1"){
								?>
									
		
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default" style="background-color: #9FDF28">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
						
						
								<?php
								if ($puntajetotal == "0"){
								?>
									
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default" style="background-color: #28DF39">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
						
						
						
								<?php
								if ($puntajetotal == "1"){
								?>
									
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default" style="background-color: #28DF9F">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
						
						
								<?php
								if ($puntajetotal == "2"){
								?>
									
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default" style="background-color: #28DFC3">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
						
								<?php
								if ($puntajetotal == "3"){
								?>
									
			
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default" style="background-color: #28D4DF">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>

								<?php
								if ($puntajetotal == "4"){
								?>
									
	
										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default" style="background-color: #28B0DF">4</button>
											<button type="button" class="btn btn-default">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
						
								<?php
								if ($puntajetotal >= "5"){
								?>
									

										<div class="btn-toolbar" role="toolbar">
										  <div class="btn-group btn-group-xs">
											<button type="button" class="btn btn-default">-5</button>
											<button type="button" class="btn btn-default">-4</button>
											<button type="button" class="btn btn-default">-3</button>
											<button type="button" class="btn btn-default">-2</button>
											<button type="button" class="btn btn-default">-1</button>
											<button type="button" class="btn btn-default">0</button>
											<button type="button" class="btn btn-default">1</button>
											<button type="button" class="btn btn-default">2</button>
											<button type="button" class="btn btn-default">3</button>
											<button type="button" class="btn btn-default">4</button>
											<button type="button" class="btn btn-default" style="background-color: #2868DF">5</button>
											
										  </div>
										  </div>
								<?php
									}
									?>						
							
							
							
									</div>
								
						</div>
		
						<div class="row col-md-2">
							<div class="col-md-12">
								<strong>Stock :<?php echo $stock ?></strong>
							</div>
								
						
						
							<div class="col-md-12"><?php if ($permuta == "permuta"&&$activo =="si"){ ?>
							PERMUTA
							<?php } 
							if ($permuta == "nopermuta") {?>  
							No permuta  
							<?php }?></div>
							
							
							<div class="col-md-12">Para Comprar Inicia sesion <a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a></div>
							
					
							
						</div>
					
				</div>			
			</div>				
		<div class="container">
			<div class="col-md-12">	
					
					
						<div class="row col-xs-6 col-sm-3 col-md-3 sidebar-offcanvas aling-left" id="sidebar">
						  <div class="list-group"><b>
						 	<a href="menucategoria.php?categoria=ARTE&pagina=0" class="list-group-item">ARTE&nbsp <p class="fa fa-paint-brush fa-lg"></p></a>
							<a href="menucategoria.php?categoria=TECNOLOGIA&pagina=0" class="list-group-item">TECNOLOGIA&nbsp <p class="fa fa-laptop fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MODA&pagina=0" class="list-group-item">MODA&nbsp <p class="fa fa-female fa-lg"></p></a>
							<a href="menucategoria.php?categoria=HOGAR&pagina=0" class="list-group-item">HOGAR&nbsp <p class="fa fa-home fa-lg"></p></a>
							<a href="menucategoria.php?categoria=VEHICULOS&pagina=0" class="list-group-item">VEHICULOS&nbsp <p class="fa fa-car fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MUSICA&pagina=0" class="list-group-item">MUSICA&nbsp <p class="fa fa-music fa-lg"></p></a>
							<a href="menucategoria.php?categoria=DEPORTE&pagina=0" class="list-group-item">DEPORTE&nbsp <p class="fa fa-soccer-ball-o fa-lg"></p></a>
							<a href="menucategoria.php?categoria=PASATIEMPOS&pagina=0" class="list-group-item">PASATIEMPOS&nbsp <p class="fa fa-ticket fa-lg"></p></a>
							<a href="menucategoria.php?categoria=OTROS&pagina=0" class="list-group-item">OTROS&nbsp <p class="fa fa-cubes fa-lg"></p></a>
							</b>
						  </div>
						</div>
					
				
		
			<div class="col-md-5">
				<div class="container">
				<div class="text-center">
				<h3>DESCRIPCION:</h3>
				</div>
					<form action="">
						<textarea name="descrip" id="" cols="58" rows="20" readonly><?php echo $descripcion ?></textarea>
					</form>
				</div>
			</div>
			
											<?php
													
												$conex = conectar();
												$tr = new Publicacion('',$id_usup);
												$datos_tr=$tr->trae4PubliUsu($conex);
												$cuentatr=count($datos_tr);
								?>
											

			

			
			
			
			
			<div class="col-md-4">
									
					<div class="col-md-12">
					<h6>MAS PUBLICACIONES DE ESTE USUARIO</h6>
					
													<?php
												for ($i=0;$i<$cuentatr;$i++)
												{
								?>
		
										
									<?php $id_pubtr = $datos_tr[$i][0]?>
									<?php $id_usuptr = $datos_tr[$i][1]?>
									<?php $nom_pubtr = $datos_tr[$i][2]?>
									<?php $preciotr = $datos_tr[$i][3]?>
									<?php $stocktr = $datos_tr[$i][4]?>
									<?php $descripciontr = $datos_tr[$i][5]?>
									<?php $imgportadatr = $datos_tr[$i][6]?>
									<?php $img02tr = $datos_tr[$i][7]?>
									<?php $img03tr = $datos_tr[$i][8]?>
									<?php $estadotr = $datos_tr[$i][9]?>
									<?php $fechatr = $datos_tr[$i][10]?>
									<?php $permutatr = $datos_tr[$i][11]?>
									<?php $categoriatr = $datos_tr[$i][12]?>
									<?php $denunciadotr = $datos_tr[$i][13]?>
									<?php $activotr = $datos_tr[$i][14]?>
										

										

						
							<div class="col-md-12">
							<div class="panel panel-default">
								<div class="panel-body">
									<div class="panel panel-default col-md-4">
										<img src="../ImagenesPubli/<?php echo $datos_tr[$i][1] ?>/<?php echo $datos_tr[$i][2] ?>/<?php echo $datos_tr[$i][6] ?>" alt="imagen" width="50" height="50">
																			
									</div>
									<div class="panel panel-default col-md-8">
									<h6><strong><a style="color:#000000" href="articulo.php?id_pub=<?php echo $datos_tr[$i][0]?>&foto=0" value="<?php echo $datos_tr[$i][2]?>"  ><?php echo $datos_tr[$i][2]?></a></strong></h6>
									<small> Precio: $&nbsp<?php echo $datos_tr[$i][3]?></small><br>
									</div>

								</div>
							</div>
							</div>
							
								<?php
								}
								?>

					</div>
				</div>			
		


		</div>
	</div>
		
	<div class="container">
		<div class="col-md-12">
			<div class="text-center">
				<h3>DEJAR COMENTARIO:</h3>
				</div>
				<form action="">
					<textarea name="comenta" id="" cols="150" rows="3"></textarea><br>
					
								Para Comentar Inicia sesion <a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a>

				</form>
			</div>
		</div>
		
		
	
			
	<div class="container">
			
		<div class="col-md-12">
			
			
			<div class="text-center">
				<h3>PREGUNTAS REALIZADAS</h3>
				</div>
				<form action="../Logica/procesadenunciacomentario.php" method="POST">
					<div class="row" >
					<?php
					for ($i=0;$i<$cuentac;$i++)
					{
					?>
						<div class="panel panel-default">
							<div class="panel-body">
								<ul>
									<li name="id_comentario"><?php echo $datos_c[$i][0]?></li>
										<li><strong>Comentario : </strong><br><option value="<?php echo $datos_c[$i][0]?>"  ><?php echo $datos_c[$i][3]?></option></li><br>
										<li>Respuesta : <br><option value="<?php echo $datos_c[$i][0]?>"  ><?php echo $datos_c[$i][5]?></option></li>
									</ul>
									<button name="id_comentario" class="btn btn-sm btn-danger btn-block" type="submit" style='width:75px; height:30px' value="<?php echo $datos_c[$i][0]?>">Denunciar</button>
								</div>
							</div>
							<input  type="hidden" name="id_pub" value= "<?php echo $id_pub; ?>" />
					<?php
					}
					?>	
								
							</div>
					</form>
				</form>
			</div>
		</div>






 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>

								<?php
									
								}
								}
								?>

<?php

?>