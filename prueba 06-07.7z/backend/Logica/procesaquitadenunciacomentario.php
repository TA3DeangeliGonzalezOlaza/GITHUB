<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Comenta.class.php');
require_once('../clases/Transaccion.class.php');
require_once('../logica/funciones.php');
require_once('../clases/Logs.class.php'); 

$idcom= strip_tags(trim($_GET['idcom']));
$id_admin= strip_tags(trim($_GET['id_admin']));
$nom_admin= strip_tags(trim($_GET['nom_admin']));
$fecha= strip_tags(trim($_GET['fecha']));
$accion= strip_tags(trim($_GET['accion']));

		$conex = conectar();
		$d = new Comenta($idcom);
		$datos_d=$d->QuitaDenunciacomen($conex);
		
		$conex = conectar();
		$l = new Logs('',$id_admin,$nom_admin,$fecha,$accion);
		$datos_l=$l->alta($conex);

	?>
				 <script type="text/javascript">
		 
						window.alert("Al comentario N° <?php echo $idcom ?> se le retiro la denuncia");
						location.href="../presentacion/BackComenta.php";
				</script>