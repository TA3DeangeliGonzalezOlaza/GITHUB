<?php
session_start();
require_once('../logica/funciones.php');
require_once('../presentacion/Login.php');
require_once('../clases/Persona.class.php');
require_once('../clases/Usuario.class.php');
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";

//----------------------------Variables por Form

     $ci_per=strip_tags($_POST['ci']); // 
	 $nick_per=strip_tags($_POST['nick']); 
     $pass_per=md5(strip_tags($_POST['pass'])); 
     $nom1_per=strip_tags($_POST['nom1']); 
     $nom2_per=strip_tags($_POST['nom2']);
     $ape1_per=strip_tags($_POST['ape1']); 
     $ape2_per=strip_tags($_POST['ape2']); 
     $email_per=strip_tags($_POST['mail']);
	 $tel_per=strip_tags($_POST['tel']); 
	 $dir_per=strip_tags($_POST['dir']); 
	 $modo=strip_tags($_POST['Modo']);
	 
	 $largo=strlen($_POST['ci']);

	 
$mensaje="";
$ejecucionOK=true;

$cedula="";

$error="";
$mailerror="";
$cierror="";

$numeros = array(2,9,8,7,6,3,4,1);

$largocoef = count($numeros);

$largoreal = $largo -1;

$suma=0;

$operacion=0;


		for ($i=0 ; $i<$largoreal; $i++)
		{
			
			for ($f=0 ; $f<$largocoef; $f++)
			{
				
				$operacion = $ci_per[$i]*$numeros[$f];
				//echo $ci_per[$i];
				//echo $numeros[$f];
				//echo $operacion;
				
				$suma = $suma+$operacion;
				$i= $i+1;
			}	
		}

		//echo $suma;
		
		//echo $largocoef;
		
		if ( ($suma % 10) == 0 )
			{
				$cedula= "valida";
				
			}
			else
			{
				$cedula= "ES MALA";
								
				?>
					<script type="text/javascript">
			 
							window.alert("La cedula no es valida.");
			
					</script>
				<?php
				
			}

			
			
												
													$conex = conectar();
													$d = new Persona();
													$datos_d=$d->consultaTodos($conex);
													$cuenta=count($datos_d);
													
												
												for ($n=0;$n<$cuenta;$n++)
												{
													
													if ($nick_per==$datos_d[$n][2])
													{
														$error="Nombre ya esta en uso";
														
														
													}
												
												}
												
												
												for ($m=0;$m<$cuenta;$m++)
												{
													
													if ($email_per==$datos_d[$m][8])
													{
														$mailerror="</br>Mail ya esta en uso";
														
														
													}

												}
												
												
												for ($r=0;$r<$cuenta;$r++)
												{
													
													if ($ci_per==$datos_d[$r][1])
													{
														$cierror="</br>Cedula ya esta en uso";
														
														
													}

												}

												echo $error;
												echo $mailerror;
												echo $cierror;
			
			



if (($cedula=="valida")&&(!$error=="Nombre ya esta en uso")&&(!$mailerror=="</br>Mail ya esta en uso")&&(!$cierror=="</br>Cedula ya esta en uso")){

//Se conecta a la base
$conex = conectar();
if (($modo == "ALTA")&&($mensaje == ""))
{		
	
	$login= strip_tags($_POST['nick']);
	$password= strip_tags($_POST['pass']);
	//Se crea un objeto con los datos de los cuadros de texto del formulario
	$u = new Persona('',$ci_per,$nick_per,$pass_per,$nom1_per,$nom2_per,$ape1_per,$ape2_per,$email_per,$tel_per,$dir_per);
	


	$ejecucionOK=$u->alta($conex);
	

	
	
	
	if ($ejecucionOK)
	{
			?>
				 <script type="text/javascript">
		 
						window.alert("Los datos de Usuario del Sist. se ingresaron correctamente.");
						location.href="../presentacion/index.php";
				</script>
			<?php

	}
	else
	{
			?>
				 <script type="text/javascript">
		 
						window.alert("Error al ingresar los datos de Usuario.");
		
				</script>
			<?php
   
	} 
}
}

//Desconectar de la base de datos
desconectar($conex);


?>
