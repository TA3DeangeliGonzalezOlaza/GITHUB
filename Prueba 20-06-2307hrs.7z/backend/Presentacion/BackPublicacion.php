<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Persona.class.php');
require_once('../clases/Comenta.class.php');
require_once('../clases/Transaccion.class.php');	
require_once('../clases/Usuario.class.php');	
require_once('../clases/Permuta.class.php'); 


$busqueda=strip_tags($_GET['keywords']);  
     
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
		<div class="container">
			<nav class="navbar navbar-inverse navbar-fixed-top">
				  <div class="container">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					  </button>
					  <a class="navbar-brand" href="menu.php">BACKEND </a>
					 


					</div>
					
					<div id="navbar" class="navbar-collapse collapse">
					
					  <form class="navbar-form navbar-right">
					  
						<div class="navbar-brand"><label>Bienvenido <?php echo $_SESSION["LOGIN"];?> <a href="../logica/salir.php" class="btn btn-warning btn-sm">Logout</a></label></div>
					  				  

					  </form>
					  
					</div><!--/.navbar-collapse -->
				  </div>
			</nav>
		</div>
		
		</div>
		<div class="jumbotron">
			<div class="container">
				<div class="row">
				<div> <h3>PUBLICACIONES</h3></div>
				
											<div class="col-md-12">						
							<a href="BackUsuario.php?keywords=0" class="btn btn-warning btn-sm">Usuarios</a>
							<a href="BackPersona.php?keywords=0" class="btn btn-warning btn-sm">Personas</a>
							<a href="BackPublicacion.php?keywords=0" class="btn btn-warning btn-sm">Publicaciones</a>
							<a href="BackTransaccion.php?keywords=0" class="btn btn-warning btn-sm">Transacciones</a>
							<a href="BackComenta.php?keywords=0" class="btn btn-warning btn-sm">Comentarios</a>
							<a href="BackPermuta.php?keywords=0" class="btn btn-warning btn-sm">Permutas</a>
							</div>
						<div class="col-md-12 ">
							<div class="panel panel-default">
							<div class="col-md-4">
							<br>

									<form class="" action="BackPublicacion.php" method="get">
									Ingresa N° de PUBLICACION
										<label for="search_box">
										<span> </span>
										</label>
										<input name="keywords" id="search_box" type="text" placeholder="Presiona Enter" >
										<input type="hidden" name="action" value="do_search" class="boton44"/>
										
									</form>	
									

							</div>
							
							
							
								<div class="panel-body">
										<table class="table">
																
																
													<tr>
														<th># ID Publicacion</th>
														<th># ID Usuario</th>
														<th>Nombre</th>
														<th>Precio</th>
														<th>Stock</th>
														<th>Imagen Portada</th>
														<th>Estado</th>
														<th>Fecha de publicacion</th>
														<th>Acepta Permuta</th>
														<th>Denuncia</th>
														<th>Activo</th>
														

													</tr>										
												<?php
												
													$pubtotal="0";
													$pubactivas="0";
													$pubdenunciadas="0";
													$pubbaja="0";
													$conex = conectar();
													$d = new Publicacion($busqueda);
													$datos_d=$d->consultaUno($conex);
													$cuenta=count($datos_d);
												?>
													
												<?php
												for ($i=0;$i<$cuenta;$i++)
												{
												?>
													<tr >
													
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][0]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][1]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][2]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  >$&nbsp<?php echo $datos_d[$i][3]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][4]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][6]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][9]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][10]?></a></td>
															<td><a value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][11]?></a></td>
															
															
															
															<?php
															if ($datos_d[$i][13]==1){
															?>
															<td><span title="Denunciado" style="color:C16521" class="fa fa-thumbs-o-down "></span></td>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][13]==0){
															?>
															<td><span title="OK" style="color:35C121" class="fa fa-thumbs-o-up"></span></a></td>
															
															<?php
															}
															?>
															
															
										
															
															
															<?php
															if ($datos_d[$i][14]=="si"){
															?>
															<td><span title="Activa" style="color:35C121" class="glyphicon glyphicon-ok "></span></td>
															<td><a href="../Logica/procesafinpublicacion.php?id_pub=<?php echo $datos_d[$i][0]?>"class="btn btn-Danger btn-sm">FINALIZA</a></td>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][14]=="no"){
															?>
															<td><span title="Finalizada" style="color:C16521" class="glyphicon glyphicon-remove"></span></a></td>
															
															<?php
															}
															?>
															
															
															
															
															
															
															
															
															
															

														

													</tr>

												<?php
												}
												?>				
	
										</table>
								
								
								
								</div>
							</div>
						
						</div>
						
						
						

									
												<?php
												
													$pubtotal="0";
													$pubactivas="0";
													$pubdenunciadas="0";
													$pubbaja="0";
													$conex = conectar();
													$d = new Publicacion();
													$datos_d=$d->consultaTodos($conex);
													$cuenta=count($datos_d);
												?>
													
												<?php
												for ($i=0;$i<$cuenta;$i++)
												{
												?>

																								<?php	
												if ($datos_d[$i][13]==1){
													
													$pubdenunciadas = $pubdenunciadas+1;
													}
												if ($datos_d[$i][14]=="si"){
													
													$pubactivas = $pubactivas+1;
													}
												if ($datos_d[$i][14]=="no"){
													
													$pubbaja = $pubbaja+1;
													}
												$pubtotal = $pubtotal+1;			
												?>	
												<?php
												}
												?>				
	

						
						
						
						
						
						
						
						<div class="col-md-12">
						
							<div class="panel panel-default">
									<div class="panel-body">
										<div class="col-md-3">
										Publicaciones Activas <br>
										<?php
												
												
												echo $pubactivas;
												
																									
										?>	
											</div>
											
											<div class="col-md-3">
											Publicaciones Denunciadas <br>
											<a href="BackPublicacionDenunciadas.php" class="btn btn-warning btn-sm">Denunciadas</a>
										<?php
																						
												echo $pubdenunciadas;
												
										?>	
											</div>
											
											<div class="col-md-3">
											TOTAL Finalizadas <br>
										<?php
																						
												echo $pubbaja;
												
										?>	
											</div>
											
											<div class="col-md-3">
											TOTAL Publicaciones registradas <br>
										<?php
																						
												echo $pubtotal;
												
										?>	
											</div>
							
									</div>
							</div>
						</div>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
							<div class="col-md-6">
							
								<button data-toggle="collapse" data-target="#Estadisticas" class="btn btn-sm btn-block" style="background-color:F5BC6B" ><h4 style="color:FFFFFF">Estadisticas</h4></button>	

								<div id="Estadisticas" class="collapse">
								
								
										
										<li><a href="Estadistica-MaxVenta.php"><b>Mayores vendedores</b></a></li>
										<li><a href="Estadistica-Premium.php"><b>Vendedores premium</b></a></li>
										
										<li><a href="Estadistica-Pubmasvendidas.php"><b>Publicacion mas vendida</b></a></li>
										<li><a href="Estadistica-Pubmascomentadas.php"><b>Publicacion mas comentada</b></a></li>
										
										<li><a href="Estadistica-RecaudaComision.php"><b>Recaudado de comision</b></a></li>
										<li><a href="Estadistica-RecaudaComisionmes.php"><b>Recaudacion x Mes y x Año</b></a></li>
								
								
								
								
								
								
								
								
								
								
								</div>
													
													
							</div>	

				</div>	
		
			</div>
		</div>







 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>

<?php

?>