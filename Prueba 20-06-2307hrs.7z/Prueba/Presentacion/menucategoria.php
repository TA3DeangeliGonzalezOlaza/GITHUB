<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');	
require_once('../clases/Transaccion.class.php');
 
	  
$categoria= strip_tags(trim($_GET['categoria'])); 



													
										$num_total_registros=0;
										
										$conex = conectar();
										$p = new Publicacion('','','','','','','','','','','','',$categoria);
										$datos_p=$p->consultaCiertaCategoria($conex);
										$cuentap=count($datos_p);
									
										for ($i=0;$i<$cuentap;$i++)
										{
											$num_total_registros= $num_total_registros + 1;
										}

$TAMANO_PAGINA = 5;
if ($num_total_registros > 0) {
	//Limito la busqueda
	
        $pagina = false;
}
	//examino la pagina a mostrar y el inicio del registro a mostrar
        if (isset($_GET["pagina"])){
		$pagina = $_GET["pagina"];}

if (!$pagina) {
   $inicio = 0;
   $pagina = 1;
}
else {
   $inicio = ($pagina - 1) * $TAMANO_PAGINA;
}


//calculo el total de páginas
$total_paginas = ceil($num_total_registros / $TAMANO_PAGINA);
 

?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
		<div class="container">
			<nav class="navbar navbar-inverse navbar-fixed-top">
				  <div class="container">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					  </button>
					  <a class="navbar-brand" href="index.php">VendoYA.com</a>
					  <div class="navbar-brand">
							<form class="forma-busqueda cf" action="busqueda.php" method="post">
								<label for="search_box">
								<span> </span>
								</label>
								<input name="keywords" id="search_box" type="text" placeholder="" >
								<input type="hidden" name="action" value="do_search" class="boton44"/>
							</form>
					  
					  </div>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
					
					  <form class="navbar-form navbar-right">
					  
						<!--<div class="form-group">
						  <input type="text" placeholder="Buscar..." class="form-control">
						</div>
						<button type="submit" class="btn btn-danger" >BUSCAR</button>-->
						<!--<button type="submit" class="btn btn-warning btn-sm" >Ingresar</button>-->
						<a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a>
						<a href="Login.php" class="btn btn-warning btn-sm">Registrarse</a>
		
				
		
					  </form>
					  
					</div><!--/.navbar-collapse -->
				  </div>
			</nav>
		</div>
		<div class="jumbotron">
			<div class="container">
				<div class="col-md-12">
																<?php
													$conex = conectar();
													$d = new Transaccion();
													$datos_d=$d->consulta5PubMasVendida($conex);
													$cuenta=count($datos_d);
												?>
													
												<?php
												for ($i=0;$i<$cuenta;$i++)
												{	}
									?>
							
									<div id="myCarousel" class="carousel slide" data-ride="carousel">

										  <!-- Indicators -->
										  <ol class="carousel-indicators">
											<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
											<li data-target="#myCarousel" data-slide-to="1"></li>
											<li data-target="#myCarousel" data-slide-to="2"></li>
											<li data-target="#myCarousel" data-slide-to="3"></li>
											<li data-target="#myCarousel" data-slide-to="4"></li>
										  </ol>

										  <!-- Wrapper for slides -->
										  <div class="carousel-inner" style="background-color:#f0ad4e">
											<div class="item active">
											<div class="container">
												<div class="col-md-12 col-md-offset-2">
											   <h1><a style="color:#FFFFFF" href="articulo.php?id_pub=<?php echo $datos_d[0][0]?>&foto=0" value="<?php echo $datos_d[0][2]?>"  ><?php echo $datos_d[0][2]?></a></h1>
											   <small style="color:#FFFFFF">PRECIO $ <?php echo $datos_d[0][3]?></small>
											   <h2>LOS MAS VENDIDOS</h2>
											   </div>
											</div>
											  
											</div>

											<div class="item">
											<div class="container">
												<div class="col-md-12 col-md-offset-2">
											 <h1><a style="color:#FFFFFF" href="articulo.php?id_pub=<?php echo $datos_d[1][0]?>&foto=0" value="<?php echo $datos_d[1][2]?>"  ><?php echo $datos_d[1][2]?></a></h1>
											 <small style="color:#FFFFFF">PRECIO $ <?php echo $datos_d[1][3]?></small>
											 <h2>LOS MAS VENDIDOS</h2>
											   </div>
											</div>
											</div>

											<div class="item">
											<div class="container">
												<div class="col-md-12 col-md-offset-2">
											  	<h1><a style="color:#FFFFFF" href="articulo.php?id_pub=<?php echo $datos_d[2][0]?>&foto=0" value="<?php echo $datos_d[2][2]?>"  ><?php echo $datos_d[2][2]?></a></h1>
												<small style="color:#FFFFFF">PRECIO $ <?php echo $datos_d[2][3]?></small>
												<h2>LOS MAS VENDIDOS</h2>
											   </div>
											</div>
											</div>
											
											<div class="item">
											<div class="container">
												<div class="col-md-12 col-md-offset-2">
											<h1><a style="color:#FFFFFF" href="articulo.php?id_pub=<?php echo $datos_d[3][0]?>&foto=0" value="<?php echo $datos_d[3][2]?>"  ><?php echo $datos_d[3][2]?></a></h1>
											<small style="color:#FFFFFF">PRECIO $ <?php echo $datos_d[3][3]?></small>
											<h2>LOS MAS VENDIDOS</h2>
											   </div>
											</div>
											</div>
											
											<div class="item">
											<div class="container">
												<div class="col-md-12 col-md-offset-2">
												
											<h1><a style="color:#FFFFFF" href="articulo.php?id_pub=<?php echo $datos_d[4][0]?>&foto=0" value="<?php echo $datos_d[4][2]?>"  ><?php echo $datos_d[4][2]?></a></h1>
											<small style="color:#FFFFFF">PRECIO $ <?php echo $datos_d[4][3]?></small>											
											<h2>LOS MAS VENDIDOS</h2>
											  </div>
											</div>
											</div>
										  </div>
										  

										  <!-- Left and right controls -->
										  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
											<span class="glyphicon glyphicon-chevron-left"></span>
											<span class="sr-only">Previous</span>
										  </a>
										  <a class="right carousel-control" href="#myCarousel" data-slide="next">
											<span class="glyphicon glyphicon-chevron-right"></span>
											<span class="sr-only">Next</span>
										  </a>
									</div>

				</div>
			</div>
<br>

			<div class="col-md-12 text-center">
			
						<h6 class="fa fa-pencil-square-o">&nbsp <?php echo $num_total_registros ;?>&nbsp PUBLICACIONES OFERTADAS</h6>
			</div>
			
<br>	
			<div class="container">

				<section class="main row">
					<div class="col-md-9">
					<ul class="">
					
						
							<div class="container">
								<div class="row">
									<?php
										$conex = conectar();
										$d = new Publicacion($inicio,$TAMANO_PAGINA,'','','','','','','','','','',$categoria);
										$datos_d=$d->consultaCategoria($conex);
										$cuenta=count($datos_d);
									?>
									<?php
										for ($i=0;$i<$cuenta;$i++)
										{
										?>
										<div class="panel panel-default">
											<div class="panel-body">
											<div class="col-md-3">
											<img src="../ImagenesPubli/<?php echo $datos_d[$i][1] ?>/<?php echo $datos_d[$i][2] ?>/<?php echo $datos_d[$i][6] ?>" alt="imagen" width="100" height="100">
											</div>
											<div class="col-md-2">
											<strong>
												<a href="articulo.php?id_pub=<?php echo $datos_d[$i][0] ?>&foto=0" value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][2]?></a>
											</strong>
											</div>
											<div class="col-md-2">
												<h3>
												<strong style="color:#FF0000">
												<option value="<?php echo $datos_d[$i][0]?>"  >$<?php echo $datos_d[$i][3]?></option>
												</strong>
											</h3>
											</div>
											<div class="col-md-4" id="menu">
											<div class="panel panel-default">
											<div class="panel-body">
												<ul>
												
													<?php
															if ($datos_d[$i][11]=="permuta"){
															?>
															<td><span title="permuta" class="fa fa-handshake-o fa-lg"></span></td><br><br>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][11]=="nopermuta"){
															?>
															<td><span title="no permuta" class="fa fa-money fa-lg"></span></a></td><br><br>
															<?php
															}
													?>
												
												
													<?php
															if ($datos_d[$i][9]=="usado"){
															?>
															<td><span title="usado" class="fa fa-star-half-o fa-lg"></span> USADO</td><br><br>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][9]=="nuevo"){
															?>
															<td><span title="Nuevo" class="fa fa-star-o fa-lg"></span></a>NUEVO</td><br><br>
															<?php
															}
													?>

													
													
													<?php
															if ($datos_d[$i][19]=="1"){
															?>
															<td ><span title="Premium" class="fa fa-diamond fa-lg " style="color:28CCDF" ></span> <strong style="color:289ADF" >USUARIO PREMIUM</strong></td>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][19]=="0"){
															?>
															<td><span title="no premium" class=""></span></a></td>
															<?php
															}
													?>
													

									
												</ul>
												
											</div>
											</div>
											</div>
											</div>
											</div>
									
								<?php
								}
								?>
								</div>
							</div>
							
						<?php
				if ($total_paginas > 1) {
				   if ($pagina != 1)
					 // echo '<strong><a href="index.php?pagina='.($pagina-1).'"><a class="fa fa-arrow-circle-left" ></a></a></strong>';
				  echo '<ul class="pagination"><li><a href="menucategoria.php?pagina='.($pagina-1).'&categoria='.$categoria.'">Anterior</a></li></ul>';
					  for ($i=1;$i<=$total_paginas;$i++) {
						 if ($pagina == $i)
							//si muestro el índice de la página actual, no coloco enlace
							//echo $pagina;
							echo '<ul class="pagination"><li class="active"><a>'.$pagina.'</a></li></ul>';
						 else
							//si el índice no corresponde con la página mostrada actualmente,
							//coloco el enlace para ir a esa página
							//echo '  <a href="index.php?pagina='.$i.'">'.$i.'</a>  ';
							echo '<ul class="pagination"><li><a href="menucategoria.php?pagina='.$i.'&categoria='.$categoria.'">'.$i.'</a></li></ul>';
							
					  }
					  if ($pagina != $total_paginas)
						 //echo '<a href="index.php?pagina='.($pagina+1).'"><a class="fa fa-arrow-circle-right" ></a></a>';
					 echo '<ul class="pagination"><li><a href="menucategoria.php?pagina='.($pagina+1).'&categoria='.$categoria.'">Siguiente</a></li></ul>';
				}
						
	?>	
						


						
					</ul>
					
					
					</div>
					<div>
						<div class="col-xs-6 col-sm-3 col-md-3 sidebar-offcanvas aling-left" id="sidebar">
						  <div class="list-group"><b>
						 	<a href="menucategoria.php?categoria=ARTE&pagina=0" class="list-group-item">ARTE&nbsp <p class="fa fa-paint-brush fa-lg"></p></a>
							<a href="menucategoria.php?categoria=TECNOLOGIA&pagina=0" class="list-group-item">TECNOLOGIA&nbsp <p class="fa fa-laptop fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MODA&pagina=0" class="list-group-item">MODA&nbsp <p class="fa fa-female fa-lg"></p></a>
							<a href="menucategoria.php?categoria=HOGAR&pagina=0" class="list-group-item">HOGAR&nbsp <p class="fa fa-home fa-lg"></p></a>
							<a href="menucategoria.php?categoria=VEHICULOS&pagina=0" class="list-group-item">VEHICULOS&nbsp <p class="fa fa-car fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MUSICA&pagina=0" class="list-group-item">MUSICA&nbsp <p class="fa fa-music fa-lg"></p></a>
							<a href="menucategoria.php?categoria=DEPORTE&pagina=0" class="list-group-item">DEPORTE&nbsp <p class="fa fa-soccer-ball-o fa-lg"></p></a>
							<a href="menucategoria.php?categoria=PASATIEMPOS&pagina=0" class="list-group-item">PASATIEMPOS&nbsp <p class="fa fa-ticket fa-lg"></p></a>
							<a href="menucategoria.php?categoria=OTROS&pagina=0" class="list-group-item">OTROS&nbsp <p class="fa fa-cubes fa-lg"></p></a>
							</b>
						  </div>
						</div>
					</div>
				</section>
			</div>
		</div>









 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>

<?php

?>