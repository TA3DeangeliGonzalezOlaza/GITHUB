<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Publicacion.class.php');
require_once('../logica/funciones.php');
require_once('../presentacion/venta.php');
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";



    $id_usu=strip_tags($_POST['id_usu']); // 
	$nom_pub=strip_tags($_POST['nombre']); 
    $precio_pub=strip_tags($_POST['precio']); 
    $stock_pub=strip_tags($_POST['stock']); 
    $descripcion_pub=strip_tags($_POST['descripcion']);
    $img01_pub=($_FILES['Imagen01']['name']); 
    $img02_pub=($_FILES['Imagen02']['name']); 
    $img03_pub=($_FILES['Imagen03']['name']);
	$estado=strip_tags($_POST['estado']); 
	$fecha=strip_tags($_POST['fecha']); 
	$permuta=strip_tags($_POST['permuta']); 
	$categoria=strip_tags($_POST['categoria']);
	$denuncia=strip_tags($_POST['denuncia']);	
	
		$conex = conectar();
		$d = new Publicacion('',$id_usu,$nom_pub,$precio_pub,$stock_pub,$descripcion_pub,$img01_pub,$img02_pub,$img03_pub,$estado,$fecha,$permuta,$categoria,$denuncia);
		$datos_d=$d->alta($conex);

mkdir("../ImagenesPubli/".$id_usu."/".$nom_pub,0700,true);

		
$target_path1 = "../ImagenesPubli/".$id_usu."/".$nom_pub."/";
$target_path2 = "../ImagenesPubli/".$id_usu."/".$nom_pub."/";
$target_path3 = "../ImagenesPubli/".$id_usu."/".$nom_pub."/";

$target_path1 = $target_path1 . basename( $_FILES['Imagen01']['name']); if(move_uploaded_file($_FILES['Imagen01']['tmp_name'], $target_path1)) { echo "El archivo ". basename( $_FILES['Imagen01']['name']). " ha sido subido";
} else{
echo "Ha ocurrido un error, trate de nuevo!";
}

$target_path2 = $target_path2 . basename( $_FILES['Imagen02']['name']); if(move_uploaded_file($_FILES['Imagen02']['tmp_name'], $target_path2)) { echo "El archivo ". basename( $_FILES['Imagen02']['name']). " ha sido subido";
} else{
echo "Ha ocurrido un error, trate de nuevo!";
}

$target_path3 = $target_path3 . basename( $_FILES['Imagen03']['name']); if(move_uploaded_file($_FILES['Imagen03']['tmp_name'], $target_path3)) { echo "El archivo ". basename( $_FILES['Imagen03']['name']). " ha sido subido";
} else{
echo "Ha ocurrido un error, trate de nuevo!";
}		
		
		

		
		
		
		
		
		
	?>

				 <script type="text/javascript">
		 
						window.alert("La publicacion ha sido ingresada.");
						location.href="../presentacion/cargamenu.php";
				</script>
