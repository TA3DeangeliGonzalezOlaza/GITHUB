<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";
require_once('../clases/Persona.class.php');
require_once('../logica/funciones.php');

$ci=strip_tags($_POST['ci']);
$mail=strip_tags($_POST['mail']);



$conex = conectar();
$d = new Persona('',$ci,'','','','','','',$mail);
$datos_d=$d->resetPass($conex);

	?>
				 <script type="text/javascript">
		 
						window.alert("TU CONTRASEÑA A SIDO CAMBIADA POR 12345");
						location.href="../presentacion/index.php";
				</script>
