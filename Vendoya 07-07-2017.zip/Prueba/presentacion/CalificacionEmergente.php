<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Usuario.class.php');
require_once('../clases/Comenta.class.php');	
require_once('../clases/Transaccion.class.php');
require_once('../clases/Persona.class.php');	
require_once('../clases/Permuta.class.php');

$id_trans=strip_tags($_POST['id_trans']);
$id_usut=strip_tags($_POST['id_usut']);
$id_pubt=strip_tags($_POST['id_pubt']);  

?>


<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>

<div class="container col-md-8">
		<div class="col-md-offset-4 ">
			<div class="panel panel-default">
				<div class="panel-body">
				<div class="col-md-12">
			<h3>Califica tu COMPRA</h3>
			  <form action="../logica/procesacalificacion.php" method="POST">
					<input  type="hidden" name="id_trans" value= "<?php echo $id_trans; ?>" />
					<input  type="hidden" name="id_usut" value= "<?php echo $id_usut; ?>" />
					<input  type="hidden" name="id_pubt" value= "<?php echo $id_pubt; ?>" />
					
					
					  
					<strong>CALIFICACION </strong>&nbsp
						<select name="calificacion" id="calificacion">
						<option value="-1">Negativa</option>
						<option value="0" selected>Neutra</option>
						<option value="1">Positiva</option>
						</select>
						<br><br>
						<strong>COMENTARIO </strong><br>
						<textarea name="comentario" id="" cols="60" rows="5" placeholder="deja tu comentario..."></textarea>
					 <br><br>
					
					
					<div class="col-md-12">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-warning btn-block" type="submit">Enviar Calificacion</button>
				</form>
						</div>
						   <form action="usuario_menu.php" method="POST">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-danger btn-block" type="submit">VOLVER</button>
						   </form>
						 </div>
					</div>
				
				
				
				
				
				</div>
			</div>
		</div>
</div>
</div>



<script src="../jscript/jquery-1.12.4.min.js"> </script>

<!-- Latest compiled and minified JavaScript -->
<!--	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	-->
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"> </script>
</body>
</html>







