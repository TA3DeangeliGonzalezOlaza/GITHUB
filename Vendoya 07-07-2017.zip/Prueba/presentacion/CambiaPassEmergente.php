<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Usuario.class.php');
require_once('../clases/Comenta.class.php');	
require_once('../clases/Transaccion.class.php');
require_once('../clases/Persona.class.php');	
require_once('../clases/Permuta.class.php');

$id_per=strip_tags($_POST['id_per']);
$nick_per=strip_tags($_POST['nick_per']);
$password_per=strip_tags($_POST['password_per']);  

?>


<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
	<div class="container col-md-8">
		<div class="col-md-offset-4 ">
			<div class="panel panel-default">
				<div class="panel-body">
				<div class="col-md-12">
			<h3>Cambiar Password</h3>
			 <form action="../logica/procesaPassword.php" method="POST">
				<input  type="hidden" name="id_per" value= "<?php echo $id_per; ?>" />
				<input  type="hidden" name="nick_per" value= "<?php echo $nick_per; ?>" />
									
					<div>

								<label for="inputPassword" class="sr-only">Antigua Contraseña</label>
								<input type="password" id="inputPassword" name="old_password_per" class="form-control" placeholder="Password" value="<?php echo $password_per; ?>" ><br>
								
								<label for="inputPassword" class="sr-only">Nueva contraseña</label>
								<input type="password" id="inputPassword" name="new_password_per" class="form-control" placeholder="Nuevo Password" required="" ><br>
								
								<label for="inputPassword" class="sr-only">Verificar contraseña</label>
								<input type="password" id="inputPassword" name="new2_password_per" class="form-control" placeholder="Repite Password" required=""><br>


					</div>
					

					<div class="col-md-12">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-warning btn-block" type="submit">CAMBIAR PASSWORD</button>
				</form>
						</div>
						   <form action="usuario_menu.php" method="POST">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-danger btn-block" type="submit">VOLVER</button>
						   </form>
						 </div>
					</div>
				</div>
			</div>	
				
				
				
				</div>
			</div>
		</div>




<script src="../jscript/jquery-1.12.4.min.js"> </script>

<!-- Latest compiled and minified JavaScript -->
<!--	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	-->
<script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"> </script>
</body>
</html>


