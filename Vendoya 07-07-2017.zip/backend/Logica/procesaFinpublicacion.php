<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Publicacion.class.php');
require_once('../logica/funciones.php');
require_once('../presentacion/venta.php');
require_once('../clases/Logs.class.php'); 
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


$id_pub= strip_tags(trim($_GET['id_pub']));
$id_admin= strip_tags(trim($_GET['id_admin']));
$nom_admin= strip_tags(trim($_GET['nom_admin']));
$fecha= strip_tags(trim($_GET['fecha']));
$accion= strip_tags(trim($_GET['accion']));




		$conex = conectar();
		$d = new Publicacion($id_pub);
		$datos_d=$d->FinalizaPub($conex);
		
		$conex = conectar();
		$l = new Logs('',$id_admin,$nom_admin,$fecha,$accion);
		$datos_l=$l->alta($conex);

	?>
	
	
				 <script type="text/javascript">
		 
						window.alert("La publicacion ha sido FINALIZADA.");
						location.href="../presentacion/BackPublicacion.php";
				</script>
