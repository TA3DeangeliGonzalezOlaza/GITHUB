<?php
    define('SERVIDOR_CORREO',"smtp.gmail.com");
    define('REMITENTE', '');
    define('DIRECCION_RESPUESTA', '');
    define('DESTINATARIO_APLICACIONES','');
    define('CON_COPIA','');
    define('COPIA_OCULTA','');
    
    
?>
