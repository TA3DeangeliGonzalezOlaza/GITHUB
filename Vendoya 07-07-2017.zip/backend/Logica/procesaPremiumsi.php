<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Usuario.class.php');
require_once('../logica/funciones.php');
require_once('../clases/Logs.class.php');

$idusu= strip_tags(trim($_GET['idusu']));
$id_admin= strip_tags(trim($_GET['id_admin']));
$nom_admin= strip_tags(trim($_GET['nom_admin']));
$fecha= strip_tags(trim($_GET['fecha']));
$accion= strip_tags(trim($_GET['accion']));

		$conex = conectar();
		$d = new Usuario($idusu);
		$datos_d=$d->PremiumSiUsuario($conex);
		
		$conex = conectar();
		$l = new Logs('',$id_admin,$nom_admin,$fecha,$accion);
		$datos_l=$l->alta($conex);

	?>
				 <script type="text/javascript">
		 
						window.alert("El usuario N°<?php echo $idusu ?> ha sido promovido a Premium");
						location.href="../presentacion/BackUsuario.php";
				</script>