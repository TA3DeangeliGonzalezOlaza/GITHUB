<?php
	session_start();
	require_once('funciones.php');
	salir();
?>
	 <script type="text/javascript">
		location.href="../presentacion/index.php";
	</script>

