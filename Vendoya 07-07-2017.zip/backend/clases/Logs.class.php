<?php
require_once('../persistencia/PersistenciaLogs.class.php');

class Logs
{
    private $id_log; 
    private $id_admin; 
	private $nombre_admin; 
	private $fecha; 
	private $accion; 
	
      
    function __construct($id='',$adm='',$nom='',$fec='',$acc='')
    {
        $this->idlog= $id;
        $this->id_admin= $adm;
		$this->nombre_admin= $nom;
		$this->fecha= $fec;
		$this->accion= $acc;
	}
    
    //Métodos set
    
    public function setIdlog($id)
    {
      $this->idlog= $id;
    }
    
    public function setIdadmin($adm)
    {
      $this->id_admin= $adm;
	}
	
	public function setNomadmin($nom)
    {
      $this->nombre_admin= $nom;
    }
	
	public function setFecha($fec)
    {
      $this->fecha= $fec;
    }
	
		public function setAccion($acc)
    {
      $this->accion= $acc;
    }
	
	
    //Métodos get
    
    public function getIdlog()
    {
      return $this->idlog;
    }
    
    public function getIdadmin()
    {
      return $this->id_admin;
    }
	
	public function getNomadmin()
    {
      return $this->nombre_admin;
    }
    
    public function getFecha()
    {
      return $this->fecha;
    }
	
	    public function getAccion()
    {
      return $this->accion;
    }
	

	
     
    //Otros Métodos
    public function alta($conex)
    {
        $pu=new PersistenciaLogs;
        return ($pu->agregar($this, $conex));
    }
    
   
    
	
	
    //Devuelve true si el Login y el Password coinciden
  //  public function coincideLoginPassword($conex)
 //   {
 //       $pu= new PersistenciaCategoria;
 //       return $pu->verificarLoginPassword($this, $conex);
 //       
 //   }
}

?>