<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');	
 
$busqueda=strip_tags($_POST['keywords']);
 

?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
		<div class="container">
			<nav class="navbar navbar-inverse navbar-fixed-top">
				  <div class="container">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					  </button>
					  <a class="navbar-brand" href="index.php?categoria=Index">VendoYA.com</a>
					  <div class="navbar-brand">
							<form class="forma-busqueda cf" action="busqueda.php" method="post">
								<label for="search_box">
								<span> </span>
								</label>
								<input name="keywords" id="search_box" type="text" placeholder="" >
								<input type="hidden" name="action" value="do_search" class="boton44"/>
							</form>
					  
					  </div>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
					
					  <form class="navbar-form navbar-right">

						<a href="singin.php" class="btn btn-warning btn-sm">Ingresar</a>
						<a href="Login.php" class="btn btn-warning btn-sm">Registrarse</a>
		
				
		
					  </form>
					  
					</div><!--/.navbar-collapse -->
				  </div>
			</nav>
		</div>
		<div class="jumbotron">
			<div class="container">

				<section class="main row">
					<div class="col-md-9">
					<ul class="pre-scrollable">
					
						<li class="intem-resultado">
							<div class="container">
								<div class="row">
									<?php

										$conex = conectar();
										$d = new Publicacion('','',$busqueda);
										$datos_d=$d->BuscarPublicacion($conex);
										$cuenta=count($datos_d);										
										
									?>
									<?php
										for ($i=0;$i<$cuenta;$i++)
										{
										?>
											<div class="col-md-3">
											<img src="../ImagenesPubli/<?php echo $datos_d[$i][1] ?>/<?php echo $datos_d[$i][2] ?>/<?php echo $datos_d[$i][6] ?>" alt="imagen" width="100" height="100">
											</div>
											<div class="col-md-3">
											<strong>
												<a href="articulo.php?id_pub=<?php echo $datos_d[$i][0] ?>" value="<?php echo $datos_d[$i][0]?>"  ><?php echo $datos_d[$i][2]?></a>
											</strong>
											</div>
											<div class="col-md-2">
												<strong>
												<option value="<?php echo $datos_d[$i][0]?>"  >PRECIO $<?php echo $datos_d[$i][3]?></option>
												</strong>
											</div>
<div class="col-md-4" id="menu">
											<div class="panel panel-default">
											<div class="panel-body">
												<ul>
												
													<?php
															if ($datos_d[$i][11]=="permuta"){
															?>
															<td><span title="permuta" class="fa fa-handshake-o fa-lg"></span></td><br><br>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][11]=="nopermuta"){
															?>
															<td><span title="no permuta" class="fa fa-money fa-lg"></span></a></td><br><br>
															<?php
															}
													?>
												
												
													<?php
															if ($datos_d[$i][9]=="usado"){
															?>
															<td><span title="usado" class="fa fa-star-half-o fa-lg"></span> USADO</td><br><br>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][9]=="nuevo"){
															?>
															<td><span title="Nuevo" class="fa fa-star-o fa-lg"></span></a>NUEVO</td><br><br>
															<?php
															}
													?>

													
													
													<?php
															if ($datos_d[$i][19]=="1"){
															?>
															<td ><span title="Premium" class="fa fa-diamond fa-lg " style="color:28CCDF" ></span> <strong style="color:289ADF" >USUARIO PREMIUM</strong></td>
															<?php
															}
															?>
															<?php
															if ($datos_d[$i][19]=="0"){
															?>
															<td><span title="no premium" class=""></span></a></td>
															<?php
															}
													?>
													

									
												</ul>
												
											</div>
											</div>
											</div>
									
										<?php
										}
										?>
								</div>
							</div>
						</li>


						
					</ul>
					
					
					</div>
					<div>
						<div class="col-xs-6 col-sm-3 col-md-3 sidebar-offcanvas aling-left" id="sidebar">
						  <div class="list-group"><b>
						 	<a href="menucategoria.php?categoria=ARTE" class="list-group-item">ARTE&nbsp <p class="fa fa-paint-brush fa-lg"></p></a>
							<a href="menucategoria.php?categoria=TECNOLOGIA" class="list-group-item">TECNOLOGIA&nbsp <p class="fa fa-laptop fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MODA" class="list-group-item">MODA&nbsp <p class="fa fa-female fa-lg"></p></a>
							<a href="menucategoria.php?categoria=HOGAR" class="list-group-item">HOGAR&nbsp <p class="fa fa-home fa-lg"></p></a>
							<a href="menucategoria.php?categoria=VEHICULOS" class="list-group-item">VEHICULOS&nbsp <p class="fa fa-car fa-lg"></p></a>
							<a href="menucategoria.php?categoria=MUSICA" class="list-group-item">MUSICA&nbsp <p class="fa fa-music fa-lg"></p></a>
							<a href="menucategoria.php?categoria=DEPORTE" class="list-group-item">DEPORTE&nbsp <p class="fa fa-soccer-ball-o fa-lg"></p></a>
							<a href="menucategoria.php?categoria=PASATIEMPOS" class="list-group-item">PASATIEMPOS&nbsp <p class="fa fa-ticket fa-lg"></p></a>
							<a href="menucategoria.php?categoria=OTROS" class="list-group-item">OTROS&nbsp <p class="fa fa-cubes fa-lg"></p></a>
							</b>
						  </div>
						</div>
					</div>
				</section>
			</div>
		</div>







 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>

<?php

?>