<?php
session_start();
$_SESSION["PHPSESSID"]=session_id();
echo "<script type='text/javascript' src='../jscript/funcionesGenerales.js'></script>";


require_once('../logica/funciones.php');
require_once('../clases/Publicacion.class.php');
require_once('../clases/Usuario.class.php');
require_once('../clases/Comenta.class.php');	
require_once('../clases/Transaccion.class.php');
require_once('../clases/Persona.class.php');	
require_once('../clases/Permuta.class.php');

$comentario=strip_tags($_POST['comentario']);
$id_comen=strip_tags($_POST['id_comen']);
  

?>



<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="../css/estilos.css">
<link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
	
	</head>
<body>
		<div class="container col-md-6 ">
			<div class="panel panel-default">
				<div class="panel-body">
				<div class="col-md-12">
			<h3>RESPONDER PREGUNTA</h3>
			 <h4>Comentario:</h4><br>
				  <textarea name="comentario" id="comentario" cols="70" rows="5" readonly>
				<?php
				  echo $comentario ;
				?>			  
				   </textarea>
				   <h4>Respuesta:</h4><br>
				   <form action="../logica/procesarespuesta.php" method="POST">
					<input  type="hidden" name="id_comen" value= "<?php echo $id_comen; ?>" />
								   
					  <textarea name="respuesta" id="respuesta" cols="70" rows="5">
			  
					   </textarea></br></br>
				
					<div class="col-md-12">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-warning btn-block" type="submit">Enviar Respuesta</button>
						   </form>
						</div>
						   <form action="usuario_menu.php" method="POST">
						<div class="col-md-6">
						   <button class="btn btn-sm btn-danger btn-block" type="submit">VOLVER</button>
						   </form>
						 </div>
					</div>
				</div>
				
				
				
				
				</div>
			</div>
		</div>




 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</body>
</html>














