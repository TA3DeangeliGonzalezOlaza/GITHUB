<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Usuario.class.php');
require_once('../clases/Transaccion.class.php');
require_once('../logica/funciones.php');

$idtran= strip_tags(trim($_GET['idtran']));

		$conex = conectar();
		$d = new Transaccion($idtran);
		$datos_d=$d->Comisionpaga($conex);

	?>
				 <script type="text/javascript">
		 
						window.alert("La comision de la transaccion N° : <?php echo $idtran ?> ha sido pagada");
						location.href="../presentacion/BackTransaccion.php";
				</script>