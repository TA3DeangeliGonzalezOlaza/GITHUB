<?php
if (!isset($_SESSION["PHPSESSID"])) {
	session_start(); }
require_once('../clases/Comenta.class.php');
require_once('../clases/Transaccion.class.php');
require_once('../logica/funciones.php');

$idcom= strip_tags(trim($_GET['idcom']));

		$conex = conectar();
		$d = new Comenta($idcom);
		$datos_d=$d->Eliminacomen($conex);

	?>
				 <script type="text/javascript">
		 
						window.alert("El comentario N° <?php echo $idcom ?> ha sido eliminado");
						location.href="../presentacion/BackComenta.php";
				</script>